import AdvancedLandingPage from "@/app/components/main";
export default function Page() {
  return (
      <AdvancedLandingPage />
  );
}
