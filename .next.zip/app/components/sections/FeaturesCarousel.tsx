'use client';

import { useState, useEffect, useRef } from "react";
import Image from 'next/image';
import {
  CheckCircle,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

// Components
import { TwoPanelChat } from "../ui/TwoPanelChat";
import LeadLifecycleTimeline from "../ui/LeadLifecycleTimeline";

const features = [
  {
    category: "Smart Conversations",
    title: "24/7 Support",
    description: "Experience seamless communication with our advanced AI chat interface that provides intelligent, contextual responses.",
    metrics: ["Real-time messaging", "Multi-platform support", "Smart responses"],
    button: "Try Demo",
    gradient: "from-[#1A1E2E] to-[#2D3748]",
    visualization: <TwoPanelChat />
  },
  {
    category: "Automation",
    title: "Workflow Intelligence",
    description: "Streamline your business processes with AI that learns and adapts to your specific workflows.",
    metrics: ["80% time savings", "99% accuracy rate", "Seamless integrations"],
    button: "Get Started",
    gradient: "from-[#1A1E2E] to-[#2D3748]"
  },
  {
    category: "Analytics",
    title: "Performance Insights",
    description: "Unlock powerful analytics that help you understand customer behavior and optimize performance.",
    metrics: ["Real-time dashboards", "Predictive analytics", "Custom reporting"],
    button: "View Demo",
    gradient: "from-[#1A1E2E] to-[#2D3748]"
  },
  {
    category: "Alerts",
    title: "Smart Notifications",
    description: "Stay informed with intelligent alerts that prioritize what matters most to your business.",
    metrics: ["Instant notifications", "Priority filtering", "Multi-channel alerts"],
    button: "Configure",
    gradient: "from-[#FF6700] to-[#E1A940]"
  },
  {
    category: "Intelligence",
    title: "Lead Qualification",
    description: "Automatically qualify and route leads with AI that understands your sales process.",
    metrics: ["Higher conversion rates", "Automated scoring", "CRM integration"],
    button: "Try Now",
    gradient: "from-[#1A6262] to-[#91C499]"
  },
  {
    category: "Global",
    title: "Multi-language Support",
    description: "Serve customers worldwide with AI agents that speak their language fluently.",
    metrics: ["50+ languages", "Cultural awareness", "Local compliance"],
    button: "Explore",
    gradient: "from-[#91C499] to-[#FF6700]"
  }
];

export default function FeaturesCarousel() {
  const [currentFeature, setCurrentFeature] = useState(0);
  const [isAutoScrolling, setIsAutoScrolling] = useState(true);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [extendedFeatures, setExtendedFeatures] = useState<typeof features>([]);
  const [actualIndex, setActualIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Click outside handler for the notification dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isDropdownOpen) {
        const target = event.target as Node;
        const notificationContainer = document.querySelector('.notification-container');
        if (notificationContainer && !notificationContainer.contains(target)) {
          setIsDropdownOpen(false);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isDropdownOpen]);

  // Create extended array for smooth circular animation
  useEffect(() => {
    const cloneCount = 1;
    const extended = [
      ...features.slice(-cloneCount), // Clone last feature at beginning
      ...features,
      ...features.slice(0, cloneCount), // Clone first feature at end
    ];
    setExtendedFeatures(extended);
    setActualIndex(cloneCount); // Start at the real first feature
  }, []);

  // Auto-scroll functionality
  useEffect(() => {
    if (isAutoScrolling && !isTransitioning) {
      const interval = setInterval(() => {
        nextFeature();
      }, 4000);
      return () => clearInterval(interval);
    }
  }, [isAutoScrolling, isTransitioning, actualIndex]);

  const nextFeature = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setActualIndex(prev => prev + 1);
    setCurrentFeature(prev => (prev + 1) % features.length);

    // Reset to real features if we've moved past the cloned section
    setTimeout(() => {
      if (actualIndex + 1 >= extendedFeatures.length - 1) {
        setActualIndex(1); // Jump back to real first feature
      }
      setIsTransitioning(false);
    }, 700);
  };

  const prevFeature = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setActualIndex(prev => prev - 1);
    setCurrentFeature(prev => (prev - 1 + features.length) % features.length);

    // Reset to real features if we've moved before the cloned section
    setTimeout(() => {
      if (actualIndex - 1 < 1) {
        setActualIndex(extendedFeatures.length - 2); // Jump to real last feature
      }
      setIsTransitioning(false);
    }, 700);
  };

  const goToFeature = (index: number) => {
    if (isTransitioning) return;
    
    setIsAutoScrolling(false);
    setCurrentFeature(index);
    setActualIndex(1 + index);
    setTimeout(() => setIsAutoScrolling(true), 10000);
  };

  const pauseAutoScroll = () => {
    setIsAutoScrolling(false);
    setTimeout(() => setIsAutoScrolling(true), 10000);
  };

  return (
    <div id="features" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Built to Think, Built to Scale</h2>
          <p className="text-xl text-gray-300">
            Discover how our AI agents handle the heavy lifting for your business
          </p>
        </div>

        <div className="relative">
          <div className="overflow-hidden h-[850px] sm:h-[750px] md:h-[700px] lg:h-[650px] xl:h-[600px]">
            <div
              ref={containerRef}
              className={`flex h-full ${isTransitioning ? 'transition-transform duration-700 ease-in-out' : ''}`}
              style={{ transform: `translateX(-${actualIndex * 100}%)` }}
            >
              {extendedFeatures.map((feature, index) => (
                <div key={`${index}-${feature.title}`} className="w-full flex-shrink-0 px-2 sm:px-4 py-2 sm:py-4 h-full">
                  <div className="shadow-2xl max-w-7xl mx-auto bg-white/5 border border-white/10 backdrop-blur-sm h-full rounded-2xl overflow-visible">
                    <div className="p-0 h-full">
                      <div className="grid md:grid-cols-2 grid-cols-1 h-full min-h-[800px] md:min-h-[650px]">
                        {/* Animation Content - Mobile First, Desktop Second */}
                        <div className="relative flex items-center justify-center h-96 md:h-full bg-gradient-to-br from-gray-700 to-gray-800 overflow-visible pt-4 md:pt-6 md:order-2">
                          {/* Gradient Blobs */}
                          <div className="absolute -top-24 -right-24 w-[400px] h-[400px] rounded-full bg-gradient-to-br from-[#3B82F6]/20 to-transparent blur-3xl -z-10"></div>
                          <div className="absolute -bottom-24 -left-24 w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-[#14B8A6]/20 to-transparent blur-3xl -z-10"></div>
                            {/* Decorative background elements */}
                            <div className="absolute inset-0 overflow-hidden -z-10">
                              {/* Subtle grid pattern */}
                              <div className="absolute inset-0 opacity-5" style={{
                                backgroundImage: 'linear-gradient(to right, #1A6262 1px, transparent 1px), linear-gradient(to bottom, #1A6262 1px, transparent 1px)',
                                backgroundSize: '40px 40px'
                              }}></div>
                              
                              {/* Floating circles */}
                              <div className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-[#1A6262] opacity-10 blur-xl"></div>
                              <div className="absolute bottom-1/3 right-1/4 w-48 h-48 rounded-full bg-[#91C499] opacity-10 blur-xl"></div>
                              <div className="absolute top-1/3 right-1/3 w-24 h-24 rounded-full bg-[#FF6700] opacity-10 blur-xl"></div>
                              
                              {/* Corner accents */}
                              <div className="absolute top-0 right-0 w-32 h-32 border-t-2 border-r-2 border-[#1A6262] opacity-20 rounded-bl-full"></div>
                              <div className="absolute bottom-0 left-0 w-32 h-32 border-b-2 border-l-2 border-[#91C499] opacity-20 rounded-tr-full"></div>
                            </div>
                          <div className="relative w-full h-full flex items-start justify-center p-12 md:p-0 z-10">
                            {/* Smart Conversations Chat Interface */}
                            {feature.category === "Smart Conversations" && (
                              <div className="w-full h-full flex items-start justify-center p-2 md:p-4 lg:p-6 min-h-[400px] pt-8 md:pt-12">
                                {/* Responsive container with better dimensions */}
                                <div className="w-full max-w-[550px] h-full min-h-[400px] max-h-[500px] mx-auto flex items-start justify-center">
                                  {/* Enhanced background container with overflow handling */}
                                  <div className="w-full h-full bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-xl shadow-2xl border border-gray-700 overflow-hidden relative transform -translate-y-4 md:-translate-y-6">
                                    {/* Chat interface with proper scaling */}
                                    <div className="w-full h-full overflow-hidden relative">
                                      <div className="absolute inset-0 flex items-center justify-center">
                                        <div className="w-full h-full min-h-[380px] max-h-[480px] scale-[0.85] md:scale-[0.9] lg:scale-[0.95] xl:scale-100 origin-center">
                                          {feature.visualization}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* Automation Animation */}
{feature.category === "Automation" && (
  <div className="flex items-center justify-center p-8">
    <Image
      src="/images/workflowintelligence.svg"
      alt="Workflow Intelligence"
      width={500}   // increased width
      height={500}  // increased height
      className="mx-auto"
    />
  </div>
)}



                            {/* Analytics Animation */}
                            {feature.category === "Analytics" && (
                              <div className="flex items-center justify-center p-8">
                                <div className="relative w-full max-w-[500px] h-[400px] bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-2xl shadow-2xl border border-gray-700/50 overflow-hidden">
                                  <svg 
                                    key={`analytics-${currentFeature}-${actualIndex}`} 
                                    viewBox="0 0 800 600" 
                                    xmlns="http://www.w3.org/2000/svg" 
                                    className="w-full h-full"
                                  >
                                    <defs>
                                      {/* Background gradient matching theme */}
                                      <radialGradient id={`bgGradient-${actualIndex}`} cx="50%" cy="30%">
                                        <stop offset="0%" style={{stopColor:"#1f2937", stopOpacity:1}} />
                                        <stop offset="100%" style={{stopColor:"#111827", stopOpacity:1}} />
                                      </radialGradient>
                                      
                                      {/* Glow effect */}
                                      <filter id={`glow-${actualIndex}`}>
                                        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                                        <feMerge> 
                                          <feMergeNode in="coloredBlur"/>
                                          <feMergeNode in="SourceGraphic"/>
                                        </feMerge>
                                      </filter>
                                      
                                      {/* Chart gradient matching theme colors */}
                                      <linearGradient id={`chartGradient-${actualIndex}`} x1="0%" y1="0%" x2="100%" y2="0%">
                                        <stop offset="0%" style={{stopColor:"#91C499", stopOpacity:0.8}} />
                                        <stop offset="100%" style={{stopColor:"#1A6262", stopOpacity:1}} />
                                      </linearGradient>
                                    </defs>
                                    
                                    {/* Background */}
                                    <rect width="800" height="600" fill={`url(#bgGradient-${actualIndex})`} />
                                    
                                    {/* Title */}
                                    <text x="400" y="80" textAnchor="middle" fill="#9ca3af" fontFamily="Arial, sans-serif" fontSize="18" opacity="0">
                                      Overview of key performance insights
                                      <animate attributeName="opacity" values="0;1" dur="1s" begin="0.3s" fill="freeze"/>
                                    </text>
                                    
                                    {/* Metrics Table Header */}
                                    <g opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="0.8s" begin="1s" fill="freeze"/>
                                      <text x="120" y="200" fill="#9ca3af" fontFamily="Arial, sans-serif" fontSize="24" fontWeight="bold">Metric</text>
                                      <text x="320" y="200" fill="#9ca3af" fontFamily="Arial, sans-serif" fontSize="24" fontWeight="bold">Value</text>
                                      <text x="480" y="200" fill="#9ca3af" fontFamily="Arial, sans-serif" fontSize="24" fontWeight="bold">% Change</text>
                                    </g>
                                    
                                    {/* Animated line chart in top right */}
                                    <g transform="translate(600, 180)" opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="1s" begin="2s" fill="freeze"/>
                                      <path d="M0,60 Q20,50 40,45 T80,30 T120,20 T160,15" 
                                            fill="none" 
                                            stroke={`url(#chartGradient-${actualIndex})`} 
                                            strokeWidth="3" 
                                            strokeLinecap="round"
                                            filter={`url(#glow-${actualIndex})`}
                                            strokeDasharray="200"
                                            strokeDashoffset="200">
                                        <animate attributeName="stroke-dashoffset" values="200;0" dur="2s" begin="2.5s" fill="freeze"/>
                                      </path>
                                      {/* Data points */}
                                      <circle cx="0" cy="60" r="4" fill="#91C499" opacity="0">
                                        <animate attributeName="opacity" values="0;1" dur="0.3s" begin="3s" fill="freeze"/>
                                      </circle>
                                      <circle cx="40" cy="45" r="4" fill="#91C499" opacity="0">
                                        <animate attributeName="opacity" values="0;1" dur="0.3s" begin="3.3s" fill="freeze"/>
                                      </circle>
                                      <circle cx="80" cy="30" r="4" fill="#91C499" opacity="0">
                                        <animate attributeName="opacity" values="0;1" dur="0.3s" begin="3.6s" fill="freeze"/>
                                      </circle>
                                      <circle cx="120" cy="20" r="4" fill="#91C499" opacity="0">
                                        <animate attributeName="opacity" values="0;1" dur="0.3s" begin="3.9s" fill="freeze"/>
                                      </circle>
                                      <circle cx="160" cy="15" r="4" fill="#1A6262" opacity="0">
                                        <animate attributeName="opacity" values="0;1" dur="0.3s" begin="4.2s" fill="freeze"/>
                                      </circle>
                                    </g>
                                    
                                    {/* Visitors Row */}
                                    <g className="metric-row" opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="0.8s" begin="1.2s" fill="freeze"/>
                                      <rect x="100" y="220" width="480" height="50" fill="transparent" rx="8"/>
                                      <text x="120" y="250" fill="white" fontFamily="Arial, sans-serif" fontSize="22">Visitors</text>
                                      <text x="320" y="250" fill="white" fontFamily="Arial, sans-serif" fontSize="22" fontWeight="bold">
                                        <animate attributeName="fill" values="white;#91C499;white" dur="0.5s" begin="4.5s"/>
                                        12,332
                                      </text>
                                      <text x="480" y="250" fill="#91C499" fontFamily="Arial, sans-serif" fontSize="22">+ 8.3 %</text>
                                    </g>
                                    
                                    {/* Revenue Row */}
                                    <g className="metric-row" opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="0.8s" begin="1.4s" fill="freeze"/>
                                      <rect x="100" y="280" width="480" height="50" fill="transparent" rx="8"/>
                                      <text x="120" y="310" fill="white" fontFamily="Arial, sans-serif" fontSize="22">Revenue</text>
                                      <text x="320" y="310" fill="white" fontFamily="Arial, sans-serif" fontSize="22" fontWeight="bold">
                                        <animate attributeName="fill" values="white;#91C499;white" dur="0.5s" begin="5s"/>
                                        $24,507
                                      </text>
                                      <text x="480" y="310" fill="#91C499" fontFamily="Arial, sans-serif" fontSize="22">+ 6.5 %</text>
                                    </g>
                                    
                                    {/* Conversion Rate Row */}
                                    <g className="metric-row" opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="0.8s" begin="1.6s" fill="freeze"/>
                                      <rect x="100" y="340" width="480" height="50" fill="transparent" rx="8"/>
                                      <text x="120" y="370" fill="white" fontFamily="Arial, sans-serif" fontSize="22">Conversion Rate</text>
                                      <text x="320" y="370" fill="white" fontFamily="Arial, sans-serif" fontSize="22" fontWeight="bold">
                                        <animate attributeName="fill" values="white;#91C499;white" dur="0.5s" begin="5.5s"/>
                                        3.2%
                                      </text>
                                      <text x="480" y="370" fill="#91C499" fontFamily="Arial, sans-serif" fontSize="22">+ 0.4 %</text>
                                    </g>
                                    
                                    {/* Time Metrics Row */}
                                    <g className="metric-row" opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="0.8s" begin="1.8s" fill="freeze"/>
                                      <rect x="100" y="400" width="480" height="50" fill="transparent" rx="8"/>
                                      <text x="120" y="430" fill="white" fontFamily="Arial, sans-serif" fontSize="22">Avg. Session</text>
                                      <text x="320" y="430" fill="white" fontFamily="Arial, sans-serif" fontSize="22" fontWeight="bold">
                                        <animate attributeName="fill" values="white;#f59e0b;white" dur="0.5s" begin="6s"/>
                                        3m 12s
                                      </text>
                                      <text x="480" y="430" fill="#f59e0b" fontFamily="Arial, sans-serif" fontSize="22">- 2.1 %</text>
                                    </g>
                                    
                                    {/* Pie Chart */}
                                    <g transform="translate(200, 520)" opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="1s" begin="2.5s" fill="freeze"/>
                                      
                                      {/* Active segment (40%) */}
                                      <path d="M 0,0 L 0,-50 A 50,50 0 0,1 47.02,-15.45 Z" 
                                            fill="#1A6262" 
                                            stroke="#374151" 
                                            strokeWidth="2"
                                            style={{ transformOrigin: "0 0" }}>
                                        <animateTransform attributeName="transform" 
                                                          type="scale" 
                                                          values="0;1.05;1" 
                                                          dur="0.6s" 
                                                          begin="3s" 
                                                          fill="freeze"/>
                                      </path>
                                      
                                      {/* Interested segment (55%) */}
                                      <path d="M 0,0 L 47.02,-15.45 A 50,50 0 1,1 -38.27,32.14 Z" 
                                            fill="#91C499" 
                                            stroke="#374151" 
                                            strokeWidth="2"
                                            style={{ transformOrigin: "0 0" }}>
                                        <animateTransform attributeName="transform" 
                                                          type="scale" 
                                                          values="0;1.05;1" 
                                                          dur="0.6s" 
                                                          begin="3.3s" 
                                                          fill="freeze"/>
                                      </path>
                                      
                                      {/* Cold segment (5%) */}
                                      <path d="M 0,0 L -38.27,32.14 A 50,50 0 0,1 0,-50 Z" 
                                            fill="#f97316" 
                                            stroke="#374151" 
                                            strokeWidth="2"
                                            style={{ transformOrigin: "0 0" }}>
                                        <animateTransform attributeName="transform" 
                                                          type="scale" 
                                                          values="0;1.05;1" 
                                                          dur="0.6s" 
                                                          begin="3.6s" 
                                                          fill="freeze"/>
                                      </path>
                                    </g>
                                    
                                    {/* Legend */}
                                    <g opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="0.8s" begin="3.8s" fill="freeze"/>
                                      
                                      {/* Active */}
                                      <circle cx="400" cy="500" r="8" fill="#1A6262"/>
                                      <text x="420" y="505" fill="white" fontFamily="Arial, sans-serif" fontSize="18">Active (≥12) 40%</text>
                                      
                                      {/* Interested */}
                                      <circle cx="400" cy="530" r="8" fill="#91C499"/>
                                      <text x="420" y="535" fill="white" fontFamily="Arial, sans-serif" fontSize="18">Interested (9-11) 55%</text>
                                      
                                      {/* Cold */}
                                      <circle cx="400" cy="560" r="8" fill="#f97316"/>
                                      <text x="420" y="565" fill="white" fontFamily="Arial, sans-serif" fontSize="18">Cold (&lt;5) 5%</text>
                                    </g>
                                    
                                    {/* Pulsing animation for key metrics */}
                                    <g opacity="0">
                                      <animate attributeName="opacity" values="0;1" dur="1s" begin="6.5s" fill="freeze"/>
                                      <circle cx="590" cy="250" r="3" fill="#91C499" opacity="0.7">
                                        <animate attributeName="r" values="3;8;3" dur="2s" repeatCount="indefinite"/>
                                        <animate attributeName="opacity" values="0.7;0.2;0.7" dur="2s" repeatCount="indefinite"/>
                                      </circle>
                                      
                                      <circle cx="590" cy="310" r="3" fill="#91C499" opacity="0.7">
                                        <animate attributeName="r" values="3;8;3" dur="2s" begin="0.5s" repeatCount="indefinite"/>
                                        <animate attributeName="opacity" values="0.7;0.2;0.7" dur="2s" begin="0.5s" repeatCount="indefinite"/>
                                      </circle>
                                    </g>
                                  </svg>
                                </div>
                              </div>
                            )}

                                                        {/* Smart Notifications Animation */}
                            {feature.category === "Alerts" && (
                              <div className="w-full h-full flex items-start justify-center p-2 md:p-4 pt-8 md:pt-12">
                                <div className="relative w-full max-w-lg bg-[#0F1117] rounded-xl overflow-hidden shadow-2xl border border-gray-700/50 transform -translate-y-6 md:-translate-y-8">
                                  {/* Header with user info */}
                                  <div className="flex items-center justify-between p-3 md:p-4 border-b border-gray-800">
                                    <div className="flex items-center gap-2">
                                      <div className="relative">
                                        <input 
                                          type="text" 
                                          placeholder="Search"
                                          className="bg-[#1A1D26] text-gray-300 text-xs md:text-sm outline-none px-3 md:px-4 py-2 rounded-lg w-36 md:w-48"
                                        />
                                        <svg className="w-3 h-3 md:w-4 md:h-4 text-gray-400 absolute right-2 md:right-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-3 md:gap-4">
                                      <div className="relative cursor-pointer group notification-container">
                                        <div
                                          className="flex items-center"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setIsDropdownOpen(!isDropdownOpen);
                                          }}
                                        >
                                          <div className="relative p-2 rounded-lg hover:bg-gray-700/50 transition-all hover:scale-105 active:scale-95">
                                            {/* Bell icon with integrated notification */}
                                            <div className="relative">
                                              <svg 
                                                className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors"
                                                fill="none"
                                                stroke="currentColor"
                                                viewBox="0 0 24 24"
                                                xmlns="http://www.w3.org/2000/svg"
                                                aria-label="Notifications"
                                              >
                                                <path
                                                  strokeLinecap="round"
                                                  strokeLinejoin="round"
                                                  strokeWidth={2}
                                                  d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                                                />
                                              </svg>
                                              {/* Notification indicator perfectly integrated */}
                                              <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse border-2 border-[#0F1117] shadow-sm">
                                                <div className="absolute inset-0 w-full h-full bg-red-400 rounded-full animate-ping opacity-75"></div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>

                                        {/* Notification Dropdown */}
                                          <div 
                                            className={`fixed right-4 mt-2 w-80 bg-[#0F1117] rounded-xl shadow-xl z-50 transition-all duration-200 ease-out transform border border-gray-800 overflow-hidden ${
                                              isDropdownOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-1 pointer-events-none'
                                            }`}
                                            style={{ margin: '8px 0' }}
                                          >
                                            {/* Decorative Background Elements */}
                                            <div className="absolute inset-0 overflow-hidden">
                                              <div className="absolute top-0 right-0 w-40 h-40 bg-blue-500/5 rounded-full blur-3xl transform translate-x-20 -translate-y-20"></div>
                                              <div className="absolute bottom-0 left-0 w-40 h-40 bg-purple-500/5 rounded-full blur-3xl transform -translate-x-20 translate-y-20"></div>
                                              <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl transform -translate-x-1/2 -translate-y-1/2"></div>
                                              
                                              {/* Subtle grid pattern */}
                                              <div 
                                                className="absolute inset-0 opacity-[0.02]" 
                                                style={{
                                                  backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.1) 1px, transparent 0)`,
                                                  backgroundSize: '24px 24px'
                                                }}
                                              ></div>
                                              
                                              {/* Top accent line */}
                                              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>
                                            </div>

                                            {/* Notification List */}
                                            <div className="py-2 max-h-[280px] overflow-y-auto scrollbar-thin scrollbar-track-gray-800 scrollbar-thumb-gray-700">
                                              {[
                                                { name: 'Pravalika', message: 'A new message asking about pricing plans', time: '2m ago', color: 'bg-blue-500', type: 'message' },
                                                { name: 'Rahul', message: 'Requested a demo session for tomorrow at 3 PM', time: '5m ago', color: 'bg-emerald-500', type: 'demo' },
                                                { name: 'Ananya', message: 'Asked about technical support details', time: '10m ago', color: 'bg-purple-500', type: 'support' },
                                                { name: 'Michael', message: 'New subscription started - Enterprise Plan', time: '15m ago', color: 'bg-amber-500', type: 'subscription' },
                                                { name: 'Sarah', message: 'Updated company profile and settings', time: '25m ago', color: 'bg-rose-500', type: 'update' },
                                                { name: 'David', message: 'Generated monthly analytics report', time: '45m ago', color: 'bg-indigo-500', type: 'report' },
                                                { name: 'Emma', message: 'Scheduled integration setup meeting', time: '1h ago', color: 'bg-cyan-500', type: 'meeting' },
                                                { name: 'Alex', message: 'Raised priority support ticket #2845', time: '2h ago', color: 'bg-red-500', type: 'ticket' }
                                              ].map((notification, i) => (
                                                <div 
                                                  key={i} 
                                                  className="group relative"
                                                >
                                                  <div className="mx-2 rounded-lg bg-[#161923] hover:bg-[#1E2230] cursor-pointer transition-all">
                                                    <div className="px-3 py-2.5 flex items-start">
                                                      <div className="flex-shrink-0">
                                                        <div className={`w-8 h-8 ${notification.color} rounded-lg flex items-center justify-center text-white text-sm font-medium shadow-sm group-hover:scale-105 transition-transform ring-2 ring-gray-800`}>
                                                          {notification.name[0]}
                                                        </div>
                                                      </div>
                                                      <div className="ml-3 flex-1 min-w-0">
                                                        <div className="flex items-center justify-between">
                                                          <p className="text-sm font-semibold text-white group-hover:text-blue-400 transition-colors">{notification.name}</p>
                                                          <p className="text-[10px] text-gray-400 flex items-center pl-2">
                                                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-1.5"></span>
                                                            {notification.time}
                                                          </p>
                                                        </div>
                                                        <p className="text-[12px] text-gray-300 mt-0.5 line-clamp-1 leading-relaxed">{notification.message}</p>
                                                      </div>
                                                    </div>
                                                  </div>
                                                  {i < 7 && (
                                                    <div className="absolute left-11 right-3 border-t border-gray-800/50 h-[1px] -bottom-1"></div>
                                                  )}
                                                </div>
                                              ))}
                                            </div>

                                            {/* Footer */}
                                            <div className="border-t border-gray-800 mt-1">
                                              <a href="#" className="flex items-center justify-between px-4 py-2.5 text-xs text-blue-400 hover:text-blue-300 font-medium hover:bg-[#1E2230] transition-colors">
                                                View All Notifications
                                                <ArrowRight className="w-3 h-3 ml-1.5" />
                                              </a>
                                            </div>
                                          </div>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <span className="text-sm font-medium text-gray-300">Pravalika</span>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Analytics Cards */}
                                  <div className="grid grid-cols-2 gap-4 p-4">
                                    <div className="bg-[#1A1D26] p-4 rounded-xl">
                                      <div className="flex flex-col">
                                        <div className="flex justify-between items-start">
                                          <div>
                                            <p className="text-gray-400 text-sm font-medium mb-1">Follow-up Pending</p>
                                            <h3 className="text-2xl font-bold text-white">24</h3>
                                          </div>
                                          <div className="flex items-center text-green-500 text-sm font-medium bg-green-500/10 px-2 py-1 rounded">
                                            +4% <span className="text-gray-400 ml-1">vs last week</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="bg-[#1A1D26] p-4 rounded-xl">
                                      <div className="flex flex-col">
                                        <div className="flex justify-between items-start">
                                          <div>
                                            <p className="text-gray-400 text-sm font-medium mb-1">Human Escalations</p>
                                            <h3 className="text-2xl font-bold text-white">18</h3>
                                          </div>
                                          <div className="flex items-center text-red-500 text-sm font-medium bg-red-500/10 px-2 py-1 rounded">
                                            -26% <span className="text-gray-400 ml-1">vs last week</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="bg-[#1A1D26] p-4 rounded-xl">
                                      <div className="flex flex-col">
                                        <div className="flex justify-between items-start">
                                          <div>
                                            <p className="text-gray-400 text-sm font-medium mb-1">Response Time</p>
                                            <h3 className="text-2xl font-bold text-white">38%</h3>
                                          </div>
                                          <div className="flex items-center text-green-500 text-sm font-medium bg-green-500/10 px-2 py-1 rounded">
                                            +22% <span className="text-gray-400 ml-1">vs last week</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="bg-[#1A1D26] p-4 rounded-xl">
                                      <div className="flex flex-col">
                                        <div className="flex justify-between items-start">
                                          <div>
                                            <p className="text-gray-400 text-sm font-medium mb-1">User Satisfaction</p>
                                            <h3 className="text-2xl font-bold text-white">92%</h3>
                                          </div>
                                          <div className="flex items-center text-green-500 text-sm font-medium bg-green-500/10 px-2 py-1 rounded">
                                            +15% <span className="text-gray-400 ml-1">vs last week</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* Intelligence Animation */}
                            {feature.category === "Intelligence" && (
                              <div className="w-full h-full flex items-center justify-center">
                                <LeadLifecycleTimeline />
                              </div>
                            )}

                            {/* Global Animation */}
                            {feature.category === "Global" && (
                              <div className="relative flex items-start justify-center w-full h-full p-2 md:p-4 lg:p-6 pt-8 md:pt-12">
                                <div className="relative w-full max-w-[500px] aspect-square bg-gray-900/30 rounded-full p-3 md:p-4 backdrop-blur-sm border border-gray-800/30 shadow-2xl transform -translate-y-6 md:-translate-y-8">
                                  <svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg" className="w-full h-full transform scale-90 md:scale-95 lg:scale-100">
                                    <defs>
                                      <radialGradient id="globeGradient" cx="0.3" cy="0.3">
                                        <stop offset="0%" style={{stopColor:"#1A6262", stopOpacity:0.8}} />
                                        <stop offset="70%" style={{stopColor:"#164E63", stopOpacity:0.9}} />
                                        <stop offset="100%" style={{stopColor:"#0F3344", stopOpacity:1}} />
                                      </radialGradient>
                                      <pattern id="earthPattern" width="20" height="20" patternUnits="userSpaceOnUse">
                                        <circle cx="10" cy="10" r="1" fill="#93C5FD" opacity="0.2" />
                                      </pattern>
                                      <pattern id="continentPattern" width="200" height="200" patternUnits="userSpaceOnUse">
                                        {/* Simplified continent shapes */}
                                        <path d="M40,60 Q60,40 80,50 T120,40 T160,60 Q180,80 160,100 T120,120 T80,110 Q60,120 40,100 T40,60" 
                                              fill="#91C499" opacity="0.3"/>
                                        <path d="M140,160 Q160,140 180,150 T220,140 Q240,160 220,180 T180,170 Q160,180 140,160" 
                                              fill="#91C499" opacity="0.3"/>
                                        <path d="M20,140 Q40,120 60,130 T100,120 Q120,140 100,160 T60,150 Q40,160 20,140" 
                                              fill="#91C499" opacity="0.3"/>
                                      </pattern>
                                      <linearGradient id="oceanGradient" x1="0" y1="0" x2="1" y2="1">
                                        <stop offset="0%" style={{stopColor:"#1A6262", stopOpacity:0.4}} />
                                        <stop offset="100%" style={{stopColor:"#164E63", stopOpacity:0.6}} />
                                      </linearGradient>
                                      <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                                        <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                                        <feMerge>
                                          <feMergeNode in="coloredBlur"/>
                                          <feMergeNode in="SourceGraphic"/>
                                        </feMerge>
                                      </filter>
                                      <linearGradient id="chatBg1" x1="0" y1="0" x2="1" y2="1">
                                        <stop offset="0%" style={{stopColor:"#1E293B", stopOpacity:0.95}} />
                                        <stop offset="100%" style={{stopColor:"#0F172A", stopOpacity:0.95}} />
                                      </linearGradient>
                                    </defs>

                                    {/* Background with grid */}
                                    <rect width="400" height="400" fill="transparent" />
                                    <pattern id="smallGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                                      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1A6262" strokeWidth="0.5" opacity="0.2" />
                                    </pattern>
                                    <rect width="400" height="400" fill="url(#smallGrid)" />

                                    {/* Central Globe */}
                                    <g transform="translate(200,200)">
                                      {/* Outer rings with animation */}
                                      <circle r="90" fill="none" stroke="#1A6262" strokeWidth="1" opacity="0.1">
                                        <animate attributeName="r" values="90;95;90" dur="4s" repeatCount="indefinite" />
                                        <animate attributeName="opacity" values="0.1;0.05;0.1" dur="4s" repeatCount="indefinite" />
                                      </circle>
                                      <circle r="85" fill="none" stroke="#91C499" strokeWidth="0.5" opacity="0.2">
                                        <animate attributeName="r" values="85;88;85" dur="3s" repeatCount="indefinite" />
                                        <animate attributeName="opacity" values="0.2;0.1;0.2" dur="3s" repeatCount="indefinite" />
                                      </circle>

                                      {/* Main globe with Earth effect */}
                                      <g>
                                        {/* Ocean base */}
                                        <circle r="75" fill="url(#oceanGradient)" opacity="0.9">
                                          <animateTransform
                                            attributeName="transform"
                                            type="rotate"
                                            from="0 0 0"
                                            to="360 0 0"
                                            dur="30s"
                                            repeatCount="indefinite"/>
                                        </circle>
                                        
                                        {/* Continents */}
                                        <circle r="75" fill="url(#continentPattern)">
                                          <animateTransform
                                            attributeName="transform"
                                            type="rotate"
                                            from="360 0 0"
                                            to="0 0 0"
                                            dur="40s"
                                            repeatCount="indefinite"/>
                                        </circle>
                                        
                                        {/* Atmosphere effect */}
                                        <circle r="75" fill="url(#earthPattern)" opacity="0.3">
                                          <animate
                                            attributeName="opacity"
                                            values="0.3;0.4;0.3"
                                            dur="3s"
                                            repeatCount="indefinite"/>
                                        </circle>

                                        {/* Latitude lines */}
                                        {[-60, -30, 0, 30, 60].map((angle) => (
                                          <ellipse
                                            key={angle}
                                            rx="75"
                                            ry={75 * Math.cos((angle * Math.PI) / 180)}
                                            stroke="#1A6262"
                                            strokeWidth="0.5"
                                            fill="none"
                                            opacity="0.15"
                                          />
                                        ))}

                                        {/* Longitude lines */}
                                        <g>
                                          <animateTransform
                                            attributeName="transform"
                                            type="rotate"
                                            from="0 0 0"
                                            to="360 0 0"
                                            dur="30s"
                                            repeatCount="indefinite"/>
                                          {[0, 30, 60, 90, 120, 150].map((angle) => (
                                            <ellipse
                                              key={angle}
                                              transform={`rotate(${angle})`}
                                              rx="75"
                                              ry="75"
                                              stroke="#1A6262"
                                              strokeWidth="0.5"
                                              fill="none"
                                              opacity="0.15"
                                            />
                                          ))}
                                        </g>

                                        {/* Highlight effect */}
                                        <circle
                                          r="75"
                                          fill="url(#globeGradient)"
                                          opacity="0.1"
                                          filter="url(#glow)">
                                          <animate
                                            attributeName="opacity"
                                            values="0.1;0.2;0.1"
                                            dur="3s"
                                            repeatCount="indefinite"/>
                                        </circle>
                                      </g>

                                      {/* AI text */}
                                      <text textAnchor="middle" y="8" fill="#E0F2FE" fontSize="16" fontWeight="bold">AI</text>
                                    </g>

                                    {/* Chat Bubbles with Connection Lines */}
                                    <g>
                                      {/* English */}
                                      <line x1="95" y1="95" x2="185" y2="185" stroke="#3B82F6" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" repeatCount="indefinite"/>
                                      </line>
                                      <rect x="40" y="70" width="110" height="45" rx="22.5" fill="url(#chatBg1)" stroke="#3B82F6" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" repeatCount="indefinite"/>
                                      </rect>
                                      <text x="95" y="98" textAnchor="middle" fill="#93C5FD" fontSize="14" fontWeight="600">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" repeatCount="indefinite"/>
                                        Hello!
                                      </text>

                                      {/* Spanish */}
                                      <line x1="305" y1="95" x2="215" y2="185" stroke="#10B981" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="1.3s" repeatCount="indefinite"/>
                                      </line>
                                      <rect x="250" y="70" width="110" height="45" rx="22.5" fill="url(#chatBg1)" stroke="#10B981" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="1.3s" repeatCount="indefinite"/>
                                      </rect>
                                      <text x="305" y="98" textAnchor="middle" fill="#6EE7B7" fontSize="14" fontWeight="600">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="1.3s" repeatCount="indefinite"/>
                                        ¡Hola!
                                      </text>

                                      {/* Japanese */}
                                      <line x1="95" y1="305" x2="185" y2="215" stroke="#EC4899" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="2.6s" repeatCount="indefinite"/>
                                      </line>
                                      <rect x="40" y="280" width="110" height="45" rx="22.5" fill="url(#chatBg1)" stroke="#EC4899" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="2.6s" repeatCount="indefinite"/>
                                      </rect>
                                      <text x="95" y="308" textAnchor="middle" fill="#FBCFE8" fontSize="14" fontWeight="600">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="2.6s" repeatCount="indefinite"/>
                                        こんにちは!
                                      </text>

                                      {/* Hindi */}
                                      <line x1="305" y1="305" x2="215" y2="215" stroke="#8B5CF6" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="3.9s" repeatCount="indefinite"/>
                                      </line>
                                      <rect x="250" y="280" width="110" height="45" rx="22.5" fill="url(#chatBg1)" stroke="#8B5CF6" strokeWidth="2">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="3.9s" repeatCount="indefinite"/>
                                      </rect>
                                      <text x="305" y="308" textAnchor="middle" fill="#C4B5FD" fontSize="14" fontWeight="600">
                                        <animate attributeName="opacity" values="0;1;1;0" dur="4s" begin="3.9s" repeatCount="indefinite"/>
                                        नमस्ते!
                                      </text>

                                      {/* Animated Particles */}
                                      <circle r="3" fill="#3B82F6">
                                        <animate attributeName="opacity" values="0;1;0" dur="2s" repeatCount="indefinite"/>
                                        <animateMotion path="M95,95 Q140,140 185,185" dur="2s" repeatCount="indefinite"/>
                                      </circle>
                                      <circle r="3" fill="#10B981">
                                        <animate attributeName="opacity" values="0;1;0" dur="2s" begin="1.3s" repeatCount="indefinite"/>
                                        <animateMotion path="M305,95 Q260,140 215,185" dur="2s" begin="1.3s" repeatCount="indefinite"/>
                                      </circle>
                                      <circle r="3" fill="#EC4899">
                                        <animate attributeName="opacity" values="0;1;0" dur="2s" begin="2.6s" repeatCount="indefinite"/>
                                        <animateMotion path="M95,305 Q140,260 185,215" dur="2s" begin="2.6s" repeatCount="indefinite"/>
                                      </circle>
                                      <circle r="3" fill="#8B5CF6">
                                        <animate attributeName="opacity" values="0;1;0" dur="2s" begin="3.9s" repeatCount="indefinite"/>
                                        <animateMotion path="M305,305 Q260,260 215,215" dur="2s" begin="3.9s" repeatCount="indefinite"/>
                                      </circle>
                                    </g>
                                  </svg>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Textual Content - Mobile Second, Desktop First */}
                        <div className="p-4 md:p-6 lg:p-8 xl:p-10 flex flex-col justify-center h-full bg-gradient-to-br from-gray-800 to-gray-900 md:order-1 min-h-[400px] md:min-h-[500px] overflow-y-auto">
                          <div className="w-fit mb-3 md:mb-4 bg-[#1A6262]/20 text-[#91C499] px-3 py-1 border border-[#1A6262]/30 rounded-full text-sm">
                            {feature.category}
                          </div>
                          <h3 className="text-xl md:text-2xl lg:text-3xl font-bold mb-3 md:mb-4 lg:mb-6 text-white leading-tight">{feature.title}</h3>
                          <p className="text-gray-300 mb-4 md:mb-5 lg:mb-6 text-sm md:text-base lg:text-lg leading-relaxed">{feature.description}</p>
                          <div className="space-y-2 md:space-y-3 mb-4 md:mb-5 lg:mb-6">
                            {feature.metrics.map((metric, metricIndex) => (
                              <div key={metricIndex} className="flex items-start space-x-3">
                                <CheckCircle className="w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-[#91C499] flex-shrink-0 mt-0.5" />
                                <span className="text-xs md:text-sm lg:text-base text-gray-200 leading-relaxed">{metric}</span>
                              </div>
                            ))}
                          </div>
                          <button
                            className={`bg-gradient-to-r ${feature.gradient} text-white w-fit px-4 md:px-6 lg:px-8 py-2.5 md:py-3 text-sm md:text-base lg:text-lg rounded-lg hover:opacity-90 hover:scale-105 transition-all duration-200 flex items-center shadow-lg`}
                          >
                            {feature.button} <ArrowRight className="w-3 h-3 md:w-4 md:h-4 lg:w-5 lg:h-5 ml-2" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="flex justify-center mt-8 space-x-4">
            <button
              onClick={() => {
                pauseAutoScroll();
                prevFeature();
              }}
              disabled={isTransitioning}
              className="w-12 h-12 rounded-full border border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent flex items-center justify-center transition-all disabled:opacity-50"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            
            <div className="flex items-center space-x-2">
              {features.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToFeature(index)}
                  disabled={isTransitioning}
                  className={`w-3 h-3 rounded-full transition-all duration-300 disabled:opacity-50 ${
                    index === currentFeature
                      ? "bg-[#91C499] scale-125"
                      : "bg-gray-600 hover:bg-gray-500"
                  }`}
                />
              ))}
            </div>
            
            <button
              onClick={() => {
                pauseAutoScroll();
                nextFeature();
              }}
              disabled={isTransitioning}
              className="w-12 h-12 rounded-full border border-gray-600 text-gray-300 hover:bg-gray-700 bg-transparent flex items-center justify-center transition-all disabled:opacity-50"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}