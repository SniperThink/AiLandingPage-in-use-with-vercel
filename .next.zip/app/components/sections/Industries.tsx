import React, { useEffect, useRef, useState } from "react";
import {
  CheckCircle,
  GraduationCap,
  DollarSign,
  Home,
  Heart,
  ShoppingBag,
  Building,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

const cards = [
  {
    icon: <GraduationCap className="w-8 h-8 text-white" />,
    title: "EdTech",
    subtitle: "Universities, Online Learning, Coaching",
    subtitleColor: "text-[#91C499]",
    gradient: "from-[#91C499]/20 via-[#91C499]/10 to-[#1A6262]/20",
    iconBg: "from-[#1A6262] to-[#91C499]",
    description:
      "Respond instantly to course queries, onboard students, manage applications, and guide them through every step — without human bottlenecks.",
  },
  {
    icon: <DollarSign className="w-8 h-8 text-white" />,
    title: "Finance",
    subtitle: "Lending, insurance, Advisory",
    subtitleColor: "text-[#91C499]",
    gradient: "from-[#91C499]/20 via-[#91C499]/10 to-[#1A6262]/20",
    iconBg: "from-[#1A6262] to-[#91C499]",
    description:
      "Qualify prospects, respond to policy questions, trigger onboarding steps, and simplify complex workflows with intelligent, compliant agents",
  },
  {
    icon: <Home className="w-8 h-8 text-white" />,
    title: "Real Estate",
    subtitle: "Residential, Commercial, PropTech",
    description:
      "Engage buyers and renters, qualify leads, schedule site visits, and share listings — all before your team even picks up the phone.",
    subtitleColor: "text-[#91C499]",
    gradient: "from-[#91C499]/20 via-[#91C499]/10 to-[#1A6262]/20",
    iconBg: "from-[#1A6262] to-[#91C499]",
  },
  {
    icon: <Heart className="w-8 h-8 text-white" />,
    title: "Clinics & Healthcare",
    subtitle: "Diagnostics, OPD, Mental Health",
    description:
      "Automate appointment booking, send test updates, answer FAQs, and free up staff time — while giving patients 24/7 access to support.",
    subtitleColor: "text-[#91C499]",
    gradient: "from-[#91C499]/20 via-[#91C499]/10 to-[#1A6262]/20",
    iconBg: "from-[#1A6262] to-[#91C499]",
  },
  {
    icon: <ShoppingBag className="w-8 h-8 text-white" />,
    title: "D2C Brands",
    subtitle: "Ecommerce, Beauty, Fashion, Wellness",
    description:
      "Turn browsers into buyers. Solve product questions, assist with orders, and recover carts — all with real-time, branded conversations.",
    subtitleColor: "text-[#91C499]",
    gradient: "from-[#91C499]/20 via-[#91C499]/10 to-[#1A6262]/20",
    iconBg: "from-[#1A6262] to-[#91C499]",
  },
  {
    icon: <Building className="w-8 h-8 text-white" />,
    title: "Enterprise",
    subtitle: "SaaS, Agencies, Services",
    description:
      "Deploy agents across customer support, sales, and operations. Qualify leads, route them, and keep your team focused on high-value tasks.",
    subtitleColor: "text-[#91C499]",
    gradient: "from-[#91C499]/20 via-[#91C499]/10 to-[#1A6262]/20",
    iconBg: "from-[#1A6262] to-[#91C499]",
  },
];

export default function Industries() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [cardsPerView, setCardsPerView] = useState(3);
  const [extendedCards, setExtendedCards] = useState<typeof cards>([]);
  const [actualIndex, setActualIndex] = useState(0);

  const viewportRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  const touchStartX = useRef(0);
  const touchDeltaX = useRef(0);

  const [cardWidth, setCardWidth] = useState(0);
  const [gapPx, setGapPx] = useState(24);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const maxIndex = Math.max(0, Math.ceil(cards.length / cardsPerView) - 1);

  // Create extended array with cloned cards for smooth circular animation
  useEffect(() => {
    const cloneCount = cardsPerView;
    const extended = [
      ...cards.slice(-cloneCount), // Clone last cards at beginning
      ...cards,
      ...cards.slice(0, cloneCount), // Clone first cards at end
    ];
    setExtendedCards(extended);
    setActualIndex(cloneCount); // Start at the real first card
  }, [cardsPerView]);

  useEffect(() => {
    const measure = () => {
      if (window.innerWidth < 768) {
        setCardsPerView(1);
      } else if (window.innerWidth < 1024) {
        setCardsPerView(2);
      } else {
        setCardsPerView(3);
      }

      if (viewportRef.current && trackRef.current) {
        const gap = parseFloat(getComputedStyle(trackRef.current).gap) || 24;
        const vpWidth = viewportRef.current.offsetWidth;
        const cw = (vpWidth - gap * (cardsPerView - 1)) / cardsPerView;
        setCardWidth(cw);
        setGapPx(gap);
      }
    };

    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [cardsPerView]);

  const nextSlide = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setActualIndex(prev => prev + cardsPerView);
    setCurrentIndex(prev => (prev >= maxIndex ? 0 : prev + 1));

    // Reset to real cards if we've moved past the cloned section
    setTimeout(() => {
      if (actualIndex + cardsPerView >= extendedCards.length - cardsPerView) {
        setActualIndex(cardsPerView); // Jump back to real first card
      }
      setIsTransitioning(false);
    }, 300);
  };

  const prevSlide = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setActualIndex(prev => prev - cardsPerView);
    setCurrentIndex(prev => (prev <= 0 ? maxIndex : prev - 1));

    // Reset to real cards if we've moved before the cloned section
    setTimeout(() => {
      if (actualIndex - cardsPerView < cardsPerView) {
        setActualIndex(extendedCards.length - cardsPerView * 2); // Jump to real last card
      }
      setIsTransitioning(false);
    }, 300);
  };

  const goToSlide = (index: number) => {
    if (isTransitioning) return;
    
    setCurrentIndex(index);
    setActualIndex(cardsPerView + (index * cardsPerView));
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchDeltaX.current = 0;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchDeltaX.current = e.touches[0].clientX - touchStartX.current;
  };

  const handleTouchEnd = () => {
    const threshold = 50;
    if (touchDeltaX.current > threshold) {
      prevSlide();
    } else if (touchDeltaX.current < -threshold) {
      nextSlide();
    }
    touchDeltaX.current = 0;
  };

  const translateX = -(actualIndex * (cardWidth + gapPx));

  return (
    <section id="industries" className="py-8 min-h-screen">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-[#1A6262]/20 to-[#91C499]/20 rounded-full px-6 py-2 mb-6 border border-[#1A6262]/30">
            <CheckCircle className="w-4 h-4 text-[#91C499]" />
            <span className="text-[#91C499] font-medium">Industry Solutions</span>
          </div>
          <h2 className="text-5xl font-bold text-white mb-6 leading-tight">
            Built for Industries That Need{" "}
            <span className="bg-gradient-to-r from-[#1A6262] to-[#91C499] bg-clip-text text-transparent">
              Speed, Scale & Smart Support
            </span>
          </h2>
          <p className="text-xl text-[#D1D1D1] max-w-3xl mx-auto">
            Automate conversations throughout the entire customer journey.
          </p>
        </div>

        {/* Carousel Cards */}
        <div
          ref={viewportRef}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          className="overflow-hidden pt-10 pb-10 px-4 rounded-[20px]"
        >
          <div
            ref={trackRef}
            className={`flex gap-6 ${isTransitioning ? 'transition-transform duration-300 ease-out' : ''}`}
            style={{ transform: `translateX(${isFinite(translateX) ? translateX : 0}px)`, margin: '0 -16px' }}
          >
            {extendedCards.map((card, i) => (
              <div key={`${i}-${card.title}`}
                style={{ minWidth: cardWidth > 0 ? `${cardWidth}px` : '300px' }}
                className="bg-[#111] rounded-[20px] p-8 relative group transition-all duration-300 border border-[#222]">
                <div className={`absolute inset-0 bg-gradient-to-br ${card.gradient} rounded-[20px] pointer-events-none`}></div>
                <div className="relative z-10 h-full flex flex-col">
                <div className={`w-16 h-16 bg-gradient-to-r ${card.iconBg} rounded-full flex items-center justify-center mb-6 shadow-lg`}>
                {card.icon}
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">{card.title}</h3>
                {card.subtitle && (
                <p className={`text-sm ${card.subtitleColor} mb-4 font-medium`}>{card.subtitle}</p>)}
                <p className="text-[#D1D1D1] text-sm leading-relaxed mt-4 flex-grow">
                {card.description}
                </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Dots + Chevron Controls */}
        <div className="flex justify-center items-center mt-8 gap-4">
          <button
            onClick={prevSlide}
            disabled={isTransitioning}
            aria-label="Previous"
            className="w-10 h-10 rounded-full border border-white/20 bg-transparent flex items-center justify-center transition-all hover:scale-110 hover:border-white/40 opacity-100 disabled:opacity-50"
          >
            <ChevronLeft className="w-5 h-5 text-white" />
          </button>

          <div className="flex space-x-2">
            {Array.from({ length: maxIndex + 1 }, (_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                disabled={isTransitioning}
                aria-label={`Go to slide ${index + 1}`}
                className={`w-2.5 h-2.5 rounded-full transition-all duration-200 disabled:opacity-50 ${
                  index === currentIndex ? "bg-[#91C499] scale-125" : "bg-[#444] hover:bg-[#666]"
                }`}
              />
            ))}
          </div>

          <button
            onClick={nextSlide}
            disabled={isTransitioning}
            aria-label="Next"
            className="w-10 h-10 rounded-full border border-white/20 bg-transparent flex items-center justify-center transition-all hover:scale-110 hover:border-white/40 opacity-100 disabled:opacity-50"
          >
            <ChevronRight className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </section>
  );
}