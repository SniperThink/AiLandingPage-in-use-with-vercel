import { processSteps } from "@/data/processSteps";
import { Brain, CheckCircle } from "lucide-react";
import { useEffect, useState } from "react";
export const Process = () => {
    const [currentStep, setCurrentStep] = useState(0);
    const [isAutoPlaying, setIsAutoPlaying] = useState(true)
    // Auto-play process steps
    useEffect(() => {
        if (isAutoPlaying) {
            const interval = setInterval(() => {
                setCurrentStep((prev) => (prev + 1) % processSteps.length)
            }, 5000)
            return () => clearInterval(interval)
        }
    }, [isAutoPlaying])
    const handleStepClick = (stepIndex: number) => {
        setCurrentStep(stepIndex)
        setIsAutoPlaying(false)
        // Resume autoplay after 10 seconds of inactivity
        setTimeout(() => setIsAutoPlaying(true), 10000)
    }

    const renderStepVisual = (visual: string) => {
        switch (visual) {
            case "greeting":
                return (
                    <div className="space-y-4">
                        <div className="bg-gray-600 rounded-lg p-4 animate-slideInLeft">
                            <p className="text-white text-sm">👋 Welcome to SniperThink!</p>
                        </div>
                        <div className="bg-[#1A6262] rounded-lg p-4 ml-8 animate-slideInRight delay-500">
                            <p className="text-white text-sm">How can I help you today?</p>
                        </div>
                    </div>
                )
            case "intent":
                return (
                    <div className="relative">
                        <div className="w-32 h-32 border-4 border-[#91C499] rounded-full flex items-center justify-center animate-pulse mx-auto">
                            <Brain className="w-12 h-12 text-[#91C499]" />
                        </div>
                        <div className="mt-4 text-center text-white">
                            <p className="text-sm animate-pulse">Analyzing user intent...</p>
                        </div>
                    </div>
                )
            case "qualify":
                return (
                    <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                            <span className="text-white text-sm">Lead Score</span>
                            <span className="text-[#E1A940] font-bold">85%</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                            <span className="text-white text-sm">Budget Range</span>
                            <span className="text-green-400 font-bold">$10K+</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                            <span className="text-white text-sm">Timeline</span>
                            <span className="text-blue-400 font-bold">Q1 2024</span>
                        </div>
                    </div>
                )
            case "action":
                return (
                    <div className="text-center">
                        <div className="w-24 h-24 bg-gradient-to-r from-[#FF6700] to-[#E1A940] rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                            <CheckCircle className="w-12 h-12 text-white" />
                        </div>
                        <p className="text-white font-medium">Demo Scheduled!</p>
                        <p className="text-gray-400 text-sm mt-2">Calendar invite sent</p>
                    </div>
                )
            default:
                return null
        }
    }

    return (
        <section id="process" className="py-20">
            <div className="max-w-[1280px] mx-auto px-6 lg:px-16">
                {/* Section Header */}
                <div className="text-center mb-10">
                    <h2 className="text-4xl font-semibold text-white mb-4">
                        Our Simple & <span className="italic text-[#91C499]">Smart</span> Process
                    </h2>
                    <p className="text-base text-gray-400 text-center">
                        Everything you need to engage, qualify, and convert leads, all in one flow.
                    </p>
                </div>

                {/* Step Tabs */}
                <div className="grid grid-cols-4 gap-4 mb-12 max-w-4xl mx-auto">
                    {processSteps.map((step, index) => (
                        <button
                            key={index}
                            onClick={() => handleStepClick(index)}
                            className={`py-3 px-4 rounded-xl transition-all duration-200 cursor-pointer ${currentStep === index
                                    ? "bg-[#2A2A2D] text-white font-semibold border border-white/8"
                                    : "bg-[#1C1C1E] text-gray-400 hover:text-white"
                                }`}
                        >
                            STEP {step.number}
                        </button>
                    ))}
                </div>

                {/* Main Content Grid */}
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    {/* Left Side - Dynamic Visual */}
                    <div className="relative">
                        <div className="bg-[#1C1C1E] rounded-xl p-4 md:p-6 shadow-lg border border-gray-800">
                            {/* Dashboard Header */}
                            <div className="flex items-center justify-between mb-6">
                                <h3 className="text-white font-semibold">Process Visualization</h3>
                                <div className="flex space-x-2">
                                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                </div>
                            </div>

                            {/* Dynamic Content Based on Current Step */}
                            <div className="min-h-[300px] flex items-center justify-center">
                                {renderStepVisual(processSteps[currentStep].visual)}
                            </div>
                        </div>
                    </div>

                    {/* Right Side - Step Content */}
                    <div className="space-y-6">
                        <div className="relative">
                            <span className="text-sm text-gray-400 uppercase tracking-wide">
                                STEP {processSteps[currentStep].number}
                            </span>
                            <h3 className="text-xl font-semibold text-white mb-2">{processSteps[currentStep].title}</h3>
                            <p className="text-base text-gray-400 max-w-md">{processSteps[currentStep].description}</p>
                        </div>

                        {/* Progress Indicator */}
                        <div className="flex items-center space-x-2">
                            {processSteps.map((_, index) => (
                                <div
                                    key={index}
                                    className={`h-2 rounded-full transition-all duration-300 ${index === currentStep ? "w-8 bg-[#91C499]" : "w-2 bg-gray-600"
                                        }`}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}