
import React, { useState } from "react";
import { Zap, MessageCircle, Phone, Send, Mic, VolumeX } from "lucide-react";
import { Button } from "../ui/button";

interface HeroProps {
  activeAgent: "chat" | "call";
  setActiveAgent: React.Dispatch<React.SetStateAction<"chat" | "call">>;
}

export default function Hero({ activeAgent, setActiveAgent }: HeroProps) {
  return (
    <section id="home"className="relative px-4 py-20 py-20">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-[#1A6262]/20 to-[#91C499]/20 rounded-full px-6 py-2 mb-6 border border-[#1A6262]/30">
              <Zap className="w-4 h-4 text-[#E1A940]" />
              <span className="text-[#91C499] font-medium">{"Your 24/7 AI Agent is here"}</span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold mb-8 leading-tight">
              <span className="bg-gradient-to-r from-[#1A6262] via-[#91C499] to-[#E1A940] bg-clip-text text-transparent animate-pulse">
                Say Hello
              </span>
              <br />
              <span className="text-white">To Your Smartest Sales Assistant</span>
            </h1>

            <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              {"Deploy voice and chat agents that understand context, qualify leads, and trigger actions — all without a human in the loop.\nWork smarter, close faster, and never miss a lead."}
            </p>

            {/* Agent Type Selector */}
            <div className="flex justify-center lg:justify-start mb-8">
              <div className="bg-white/5 rounded-2xl p-2 shadow-2xl border border-white/10 backdrop-blur-sm">
                <div className="flex space-x-2">
                  <Button
                    onClick={() => setActiveAgent("chat")}
                    className={`px-6 py-3 rounded-xl transition-all duration-300 ${activeAgent === "chat"
                        ? "bg-gradient-to-r from-[#1A6262] to-[#91C499] text-white shadow-lg"
                        : "bg-transparent text-gray-300 hover:bg-gray-700/50"
                      }`}
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Chat Agent
                  </Button>
                  <Button
                    onClick={() => setActiveAgent("call")}
                    className={`px-6 py-3 rounded-xl transition-all duration-300 ${activeAgent === "call"
                        ? "bg-gradient-to-r from-[#E1A940] to-[#FF6700] text-white shadow-lg"
                        : "bg-transparent text-gray-300 hover:bg-gray-700/50"
                      }`}
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Call Agent
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button className="bg-gradient-to-r from-[#E1A940] to-[#FF6700] hover:from-[#FF6700] hover:to-[#E1A940] text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 px-8 py-4 text-lg rounded-[2rem]">
                Start Free Trial
              </Button>
              <Button
                variant="outline"
                className="border-[#1A6262] text-[#1A6262] hover:bg-[#1A6262] hover:text-white px-8 py-4 text-lg bg-transparent rounded-[2rem]"
              >
                Watch Demo
              </Button>
            </div>
          </div>

          {/* Right Mobile Mockup */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              {/* Phone Frame */}
              <div className="relative w-80 h-[600px] bg-black rounded-[3rem] p-2 shadow-2xl transform rotate-6 hover:rotate-3 transition-transform duration-500">
                <div className="w-full h-full bg-gray-900 rounded-[2.5rem] overflow-hidden relative border border-gray-700">
                  {/* Status Bar */}
                  <div className="flex justify-between items-center px-6 py-3 bg-gray-800">
                    <span className="text-sm font-medium text-white">9:41</span>
                    <div className="flex items-center space-x-1">
                      <div className="flex space-x-1">
                        <div className="w-1 h-1 bg-white rounded-full"></div>
                        <div className="w-1 h-1 bg-white rounded-full"></div>
                        <div className="w-1 h-1 bg-white rounded-full"></div>
                        <div className="w-1 h-1 bg-gray-500 rounded-full"></div>
                      </div>
                      <div className="w-6 h-3 border border-white rounded-sm">
                        <div className="w-4 h-1 bg-white rounded-sm m-0.5"></div>
                      </div>
                    </div>
                  </div>

                  {/* App Content */}
                  <div className="flex-1 p-4">
                    {activeAgent === "chat" ? (
                      // Chat Interface
                      <div className="h-full flex flex-col">
                        {/* Header */}
                        <div className="flex items-center space-x-3 mb-4 pb-3 border-b border-gray-700">
                          <div className="w-10 h-10 bg-gradient-to-r from-[#1A6262] to-[#91C499] rounded-full flex items-center justify-center">
                            <MessageCircle className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white">SniperThink AI</h3>
                            <p className="text-xs text-green-400">Online</p>
                          </div>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 space-y-3 overflow-hidden">
                          <div className="flex justify-start">
                            <div className="bg-gray-700 rounded-2xl rounded-tl-md px-4 py-2 max-w-[80%]">
                              <p className="text-sm text-gray-100">Hello! How can I help you today?</p>
                              <p className="text-xs text-gray-400 mt-1">9:41 AM</p>
                            </div>
                          </div>

                          <div className="flex justify-end">
                            <div className="bg-gradient-to-r from-[#1A6262] to-[#91C499] rounded-2xl rounded-tr-md px-4 py-2 max-w-[80%]">
                              <p className="text-sm text-white">I need help with pricing</p>
                              <p className="text-xs text-white/70 mt-1">9:42 AM</p>
                            </div>
                          </div>

                          <div className="flex justify-start">
                            <div className="bg-gray-700 rounded-2xl rounded-tl-md px-4 py-2 max-w-[80%]">
                              <p className="text-sm text-gray-100">
                                I'd be happy to help! Let me show you our plans...
                              </p>
                              <p className="text-xs text-gray-400 mt-1">9:42 AM</p>
                            </div>
                          </div>

                          {/* Typing indicator */}
                          <div className="flex justify-start">
                            <div className="bg-gray-700 rounded-2xl rounded-tl-md px-4 py-2">
                              <div className="flex space-x-1">
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Input */}
                        <div className="mt-4 flex items-center space-x-2">
                          <div className="flex-1 bg-gray-700 rounded-full px-4 py-2">
                            <p className="text-sm text-gray-400">Type a message...</p>
                          </div>
                          <div className="w-8 h-8 bg-gradient-to-r from-[#1A6262] to-[#91C499] rounded-full flex items-center justify-center">
                            <Send className="w-4 h-4 text-white" />
                          </div>
                        </div>
                      </div>
                    ) : (
                      // Call Interface
                      <div className="h-full flex flex-col items-center justify-center">
                        {/* Call Status */}
                        <div className="text-center mb-8">
                          <div className="w-24 h-24 bg-gradient-to-r from-[#E1A940] to-[#FF6700] rounded-full flex items-center justify-center mb-4 mx-auto animate-pulse">
                            <Phone className="w-12 h-12 text-white" />
                          </div>
                          <h3 className="text-lg font-semibold text-white mb-1">SniperThink AI</h3>
                          <p className="text-sm text-green-400">Connected • 00:42</p>
                        </div>

                        {/* Voice Visualization */}
                        <div className="flex items-center justify-center space-x-1 mb-8">
                          {[...Array(5)].map((_, i) => (
                            <div
                              key={i}
                              className="bg-gradient-to-t from-[#E1A940] to-[#FF6700] rounded-full animate-pulse"
                              style={{
                                width: "4px",
                                height: `${16 + Math.sin(i + Date.now() / 1000) * 8}px`,
                                animationDelay: `${i * 150}ms`,
                              }}
                            ></div>
                          ))}
                        </div>

                        {/* Call Controls */}
                        <div className="flex items-center space-x-6">
                          <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center">
                            <Mic className="w-6 h-6 text-gray-300" />
                          </div>
                          <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                            <Phone className="w-6 h-6 text-white transform rotate-[135deg]" />
                          </div>
                          <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center">
                            <VolumeX className="w-6 h-6 text-gray-300" />
                          </div>
                        </div>

                        {/* AI Speaking Indicator */}
                        <div className="mt-6 text-center">
                          <p className="text-sm text-gray-300">AI is speaking...</p>
                          <p className="text-xs text-gray-500 mt-1">"I can help you with that right away"</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-4 -left-4 w-16 h-16 bg-[#91C499]/20 rounded-full animate-bounce delay-1000"></div>
              <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-[#E1A940]/20 rounded-full animate-bounce delay-2000"></div>
              <div className="absolute top-1/2 -left-8 w-8 h-8 bg-[#1A6262]/20 rounded-full animate-ping delay-3000"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
